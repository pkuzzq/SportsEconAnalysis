This repository contains the scraper that creates a NFL coaching dataset
